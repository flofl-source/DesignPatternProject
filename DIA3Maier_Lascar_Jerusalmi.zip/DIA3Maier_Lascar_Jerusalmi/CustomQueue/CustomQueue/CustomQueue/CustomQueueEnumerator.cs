﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace CustomQueue
{
    class CustomQueueEnumerator<T> : IEnumerator<T>
    {
        private Node<T> courant;
        private CustomQueue<T> CustomQueue;

        public CustomQueueEnumerator(CustomQueue<T> liste)
        {
            courant = null;
            CustomQueue = liste;
        }

        public void Dispose()
        {
        }

        public bool MoveNext()
        {
            if (courant == null)
                courant = CustomQueue.head;
            else
                courant = courant.next;

            return courant != null;
        }

        public T Current
        {
            get
            {
                if (courant == null)
                    return default(T);
                return courant.data;
            }
        }

        object IEnumeratorCurrent
        {
            get { return Current; }
        }

        object IEnumerator.Current => throw new NotImplementedException();

        public void Reset()
        {
            courant = null;
        }
    }

}
