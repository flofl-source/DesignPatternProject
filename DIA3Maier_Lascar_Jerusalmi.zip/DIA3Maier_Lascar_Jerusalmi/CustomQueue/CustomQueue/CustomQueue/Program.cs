﻿using System;

namespace CustomQueue 
{
    class Program
    {
        static void Main(string[] args)
        {
            Node<int> var1 = new Node<int>(13);
            Node<int> var2 = new Node<int>(2);
            Node<int> var3 = new Node<int>(1);
            Node<int> var4 = new Node<int>(5);
            CustomQueue<int> cq = new CustomQueue<int>(var1);
            cq.Enqueue(var2.data);
            cq.Enqueue(var3.data);
            cq.Enqueue(var4.data);
            
            
            int test = cq.Dequeue();
            cq.printQueue();
            cq.setNode(2,new Node<int>(10));
            cq.printQueue();

            Console.WriteLine("\n\n\n");

            foreach (int data in cq)
            {
                Console.WriteLine(data);
            }




            Console.ReadKey();
        }
    }
}
