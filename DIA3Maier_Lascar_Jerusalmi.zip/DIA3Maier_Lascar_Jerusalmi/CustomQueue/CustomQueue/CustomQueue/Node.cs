﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CustomQueue
{
    class Node<T> : IEquatable<Node<T>>
    {
        //Attributes
        public T data {get; set;}
        public Node<T> next {get; set;}

        //Constructor
        public Node(T val)
        {
            data = val;
            next = null;
        }

        //Methods
        public override int GetHashCode() //The hashcode is usefull to have a comparison between 2 nodes
        {
            return data.GetHashCode();
        }
        public bool Equals(Node<T> other) // in order to compare 2 nodes
        {
            return this.GetHashCode() == other.GetHashCode();
        }

        public override string ToString()
        {
            return data.ToString();
        }

    }
}
