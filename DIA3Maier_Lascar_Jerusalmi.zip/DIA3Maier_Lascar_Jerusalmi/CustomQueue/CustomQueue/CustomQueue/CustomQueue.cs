﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace CustomQueue
{
    class CustomQueue<T> : IEnumerable
    {
        //Attributes
        public Node<T> head { get; set; }
        public Node<T> tail { get; set; }
        public int size { get; set; }

        //Constructor
        public CustomQueue(Node<T> node)
        {
            head = tail = node;
            size = 1;
        }

        //Methods

        public void Enqueue(T data)
        {
            Node<T> current = new Node<T>(data);
            if (head == null)
            {
                head = tail = current;
            }
            else
            {
                tail.next = current;
                tail = current;
            }
            size++;
        }


        public T Dequeue()
        {
            if (head == null)
            {
                throw new Exception("Queue is empty");
            }
            T data = head.data;
            head = head.next;
            size--;
            return data;
        }

        public void printQueue()
        {
            if (head == null)
            {
                throw new Exception("Queue is empty");
            }
            Node<T> current = head;
            while (current != null)
            {
                Console.WriteLine(current.data + " ");
                current = current.next;
            }
        }
        public Node<T> getNode(int idx)//from 0
        {
            if (head == null)
            {
                throw new Exception("Queue is empty");
            }
            Node<T> current = head;
            for (int i = 0; i < idx; i++)
            {
                if(current.next == null)
                {
                    throw new Exception("Out of range");
                }
                current = current.next;
            }
            Console.WriteLine(current.data);
            return current;
        }

        public void setNode(int idx, Node<T> newNode)
        {
            if (head == null)
            {
                throw new Exception("Queue is empty");
            }
            Node<T> current = head;
            for (int i = 0; i < idx -1; i++)
            {
                if (current.next == null)
                {
                    throw new Exception("Out of range");
                }
                current = current.next;
            }

            newNode.next = current.next.next;
            current.next = newNode;
            
        }

        //IEnumerable
        public IEnumerator<T> GetEnumerator()
        {
            Node<T> courant = head;
            while (courant != null)
            {
                yield return courant.data;
                courant = courant.next;
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }
}
