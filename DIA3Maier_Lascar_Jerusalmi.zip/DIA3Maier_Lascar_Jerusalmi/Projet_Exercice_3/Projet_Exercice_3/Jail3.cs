﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projet_Exercice_3
{
    class Jail3 : State
    {
        
        public void rollDices() 
        {
            Console.WriteLine("JAIL3 STATE : You stayed 3 times in jail and now you are free !");
        }
       


    }
}
