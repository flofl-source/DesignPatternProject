﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projet_Exercice_3
{
    class Jail2 : State
    {
      
        public void rollDices() 
        {
            Console.WriteLine("JAIL2 STATE : You are still in jail ! Hope you are going to do a double !");
        }
       



    }
}
