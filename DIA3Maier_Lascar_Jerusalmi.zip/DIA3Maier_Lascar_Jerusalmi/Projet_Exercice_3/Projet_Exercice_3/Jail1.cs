﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projet_Exercice_3
{
    class Jail1 : State
    {
        
        public void rollDices()
        {
            Console.WriteLine("JAIL1 STATE : You are in jail ! Hope you are going to do a double !");
        }
        
        public void updatePos() { }
        
        
    }
}
