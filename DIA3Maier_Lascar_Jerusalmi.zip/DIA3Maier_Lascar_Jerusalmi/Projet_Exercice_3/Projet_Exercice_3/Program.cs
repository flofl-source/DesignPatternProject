﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projet_Exercice_3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("");
            Player p1 = new Player("Sarah");
            Player p2 = new Player("Flora");
            Player p3 = new Player("Kevin");

            Console.WriteLine("\n--------------------------MONOPOLY -----------------------");

            Console.WriteLine("Let's play ! The players are : " + p1.id + ", " + p2.id + ", and " + p3.id);

            for (int i=1; i<=15;i++)
            {
                Console.WriteLine("\n--------------------------TURN " + Convert.ToString(i) + " -----------------------");

                Console.WriteLine("\nSarah's turn ! ");
                p1.rollDices();
                Console.WriteLine(p1.ToString());

                Console.WriteLine("\nFlora's turn ! ");
                p2.rollDices();
                Console.WriteLine(p2.ToString());

                Console.WriteLine("\nKevin's turn ! ");
                p3.rollDices();
                Console.WriteLine(p3.ToString());

                

            }

            Console.WriteLine("\n--------------------------END OF THE GAME -----------------------");







            Console.ReadKey();
        }
    }
}
