﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Projet_Exercice_3
{
    class Player : State
    {
        public string id;
        public string Id { get; set; }

        public State state { get; set; }

        private int position = 0;
        public int Position { get; set; }

        public Player(string id)
        {
            this.id = id;
            state = new Normal();
        }

        public override string ToString()
        {
            string res;
            if (this.state is Jail1 || this.state is Jail2 || this.state is Jail3)
            {
                res = "The player " + this.id + " is in jail";
            }
            else
                    {
                        res= "The player " + this.id + " is at the position " + Convert.ToString(this.position);
                    }
            return res;
            
        }

        public void updatePos(int sum)
        {
            
            this.position = this.position + sum;
            
            if (this.position>39)
            {
                this.position -=40;
            }

            if(state is Jail1 || state is  Jail2 || state is Jail3)
            {
                this.position = 10;
            }
        }


        

        public void rollDices()
        {
            state.rollDices();

            Random rand = new Random();
            int dice1 = rand.Next(1, 3);
            int dice2 = rand.Next(1, 3);
            Console.WriteLine(Convert.ToString(dice1) + " " + Convert.ToString(dice2));

            int count = 0; //number of doubles
            switch (state)
            {
                
                case Normal state_n:
                    int sum = dice1 + dice2;
                    updatePos(sum);

                    if (this.position == 10 && state is Normal)
                    {
                        Console.WriteLine("You simply visit the jail ! ");
                    }

                    // If we did a double we can replay
                    while (dice1 == dice2 && count < 3)
                    {
                        count += 1;
                        if (count < 3)
                        {
                            Console.WriteLine("Double dices ! Replay");

                            dice1 = rand.Next(1,3);
                            dice2 = rand.Next(1, 3);
                            sum = dice1 + dice2;
                            updatePos(sum);
                            Console.WriteLine(Convert.ToString(dice1) + " " + Convert.ToString(dice2));
                        }


                        //Simple visit in jail
                        if (this.position == 10&&state is Normal)
                        {
                            Console.WriteLine("You simply visit the jail ! ");
                        }
                        //Go-To-Jail case
                        if (this.position == 30)
                        {
                            Console.WriteLine("You are on the Go-To-Jail case !");
                            this.position = 10;
                            state = new Jail1();
                            Console.WriteLine("You are in jail ! :( ");
                            break;
                        }
                    }
                    
                    if (this.position == 30)
                    {
                        Console.WriteLine("You are on the Go-To-Jail case !");
                        this.position = 10;
                        state = new Jail1();
                        Console.WriteLine("You are in jail ! :( ");
                    }
                    if(count==3)
                    {
                        state = new Jail1();
                        updatePos(dice1 + dice2);
                    }

                    break;

                case Jail1 state_j1:
                    //We stay in jail if did not do a double
                    if (dice1!=dice2)
                    {
                        state = new Jail2();
                        updatePos(dice1 + dice2);
                    }
                    // come back to normal if we did a double in jail
                    if (dice1==dice2)
                    {
                        Console.WriteLine("You did a double in jail ! You are free !");
                        state = new Normal();
                        updatePos(dice1 + dice2);
                    }
                    break;
                case Jail2 state_j2:
                    if (dice1!=dice2)
                    {
                        state = new Jail3();
                        updatePos(dice1 + dice2);
                    }
                    // come back to normal if we did a double in jail
                    if (dice1==dice2)
                    {
                        Console.WriteLine("You did a double in jail ! You are free !");
                        state = new Normal();
                        updatePos(dice1 + dice2);
                    }
                    break;
                case Jail3 state_j3:
                    // Come bacl to normal when we are in jail3
                    state = new Normal();
                    updatePos(dice1 + dice2);
                    break;
            }

        }

        
       

        
    

    }
}
