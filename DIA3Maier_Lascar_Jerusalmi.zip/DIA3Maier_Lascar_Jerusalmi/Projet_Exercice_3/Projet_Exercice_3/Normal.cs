﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projet_Exercice_3
{
    class Normal : State
    {
        public void rollDices()
        {
            Console.WriteLine("NORMAL STATE : We roll the dices ! We are for now just in a normal case.");
        }
        public void updatePos(int sum) { }
    }
}
