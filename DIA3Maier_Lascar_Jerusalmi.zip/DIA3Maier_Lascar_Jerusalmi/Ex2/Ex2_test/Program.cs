﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex2_test
{
    class Program
    {
        static void Main(string[] args)
        {
            //INPTUT DATA
            string text = "Let it be, let it be, let it be, let it be! There will be an answer, let it be!";
            WordReducer wordreducer = new WordReducer();
            wordreducer.mapReduce(text);

            Console.ReadKey();


        }
    }
}
