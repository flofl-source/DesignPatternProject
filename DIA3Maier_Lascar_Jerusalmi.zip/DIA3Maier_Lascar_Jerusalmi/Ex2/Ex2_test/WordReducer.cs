﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Concurrent;
using System.Threading;

namespace Ex2_test
{

    class WordReducer
    {
        
        //INPUT - SPLITTING - MAPPING - REDUCING 
       
        //First step : SPLITTING THE TEXT INTO BLOCKS

        //We want to obtain an IEnumerable<string> object to iterate on a block of words and
        // not only on words
        public IEnumerable<string> textToBlocks(string text) 
        {
            //Turn all the capital letters into regular ones
            text = text.ToLower();
            int blockSize = 10;
            // Begginning of the block
            int startPos = 0;
            int len = 0;

            Console.WriteLine("Splitting the file text in blocks of 10 or less characters");

            for (int i = 0; i < text.Length; i++)  //for each character
            {
                //INITIALISATION OF THE END OF THE BLOCK : We want it on a space or at startPos

                //We place the cursor on the end position of the block, if he has exactly 10 characters
                i = i + blockSize;

                //If the end position cursor is out of the text limit, we just assign the end of the block to the end of the text
                if (i>text.Length-1)
                {
                    i = text.Length - 1;
                }

                //While the end of the block is not a space and not on startPos i.e. we are in the middle of a word
                //We move back
                while (i >= startPos && text[i] != ' ')
                {
                    i--;
                }
        
                //SEARCH THE LEN OF THE BLOCK

                //We there were not space on the block and we went back at startPos
                if (i == startPos) 
                {
                    //We just take the 10 characters 
                    i = i + blockSize;
                    //or less if we are out of the text limit
                    if (i> text.Length - 1)
                    {
                        i = text.Length - 1;
                    }
                    //We thus have a block of 10 characters, without spaces
                    len = (i - startPos) + 1;
                }

                //If the end of our block is well on a space
                else
                {
                    //We have a lenght of 10 or less characters, without cutting a word ! 
                    len = i - startPos;
                }

                //We take the blocks starting from the character at position startPos and with a lenght of len
                //We delete the spaces at the beginning of at the end of each blocks

                Console.WriteLine("BLOCK : "+text.Substring(startPos, len).Trim());

                yield return text.Substring(startPos, len).Trim(); 

                //We will continue creating block starting from where we stop
                startPos = i;
            }
        }

        //Second step : SPLITTING BLOCKS TO WORDS (in parallel with the first step) = MAPPING

        public BlockingCollection<string> wordCollection = new BlockingCollection<string>();
        //We can add several elements in the same time to the collection, and stop it when the adding is complete
        public void blocksToWords(string text) 
        {
            //As soon as a block from textToBlock is created, we are splitting it in words, without waiting
            // for the textToblock function to be done
            // It's the parallel execution !
            Parallel.ForEach(textToBlocks(text), wordBlock =>
            {
                string[] words = wordBlock.Split(' ');
                string cleanWord=""; //final word that we keep

                foreach (string word in words)
                {   
                    //Remove all spaces and punctuation
                    foreach (char c in word)
                    {
                        //The character of the word is a letter, number or needed signs, we keep them
                        //If not, like '?', ',', '!', we let them
                        if (char.IsLetterOrDigit(c) || c == '\'' || c == '-')
                            cleanWord=cleanWord+c;
                    }

                    //Send word to the wordCollection Blocking Collection
                    if (cleanWord.Length > 0)
                    {
                        Console.WriteLine("WORD : "+cleanWord);
                        wordCollection.Add(cleanWord);
                        //Reinitialisation
                        cleanWord="";
                    }
                }
            });

            wordCollection.CompleteAdding(); //We cannot add elements anymore
        }


        public ConcurrentDictionary<string, int> wordDico = new ConcurrentDictionary<string,int>();
        //This dictionnary allows us to use different threads in the same time

        //REDUCING
        public void countingWords() 
        {
            Console.WriteLine("\nReducing method, we count the iterations of words and we store it in wordDico :");

            //GetConsumingEnumerable is deleting the word we used, until there is nothing left
            Parallel.ForEach(wordCollection.GetConsumingEnumerable(), word =>
            {
                //if the word exists, the value linked with this key is 1
                //Everytime the word already existing appears, we increment the linked value by 1
                Console.WriteLine("COUNTING : " + word);
                wordDico.AddOrUpdate(word, 1, (key, oldValue) => Interlocked.Increment(ref oldValue));
                Console.WriteLine("STORING : " + word);
            });

            Console.WriteLine("\nFinal results : \n");
            foreach (KeyValuePair<string, int> elt in wordDico)
            {
                Console.WriteLine(elt.Key+" : "+elt.Value);
            }

        }

        //Final MapReduce method
        public void mapReduce(string fileText)
        {
            blocksToWords(fileText);
            countingWords();
        }

        
    }
}
